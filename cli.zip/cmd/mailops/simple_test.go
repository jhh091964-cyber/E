package main

import "fmt"

func main() {
    fmt.Println("MailOps CLI - Simple Test")
}
